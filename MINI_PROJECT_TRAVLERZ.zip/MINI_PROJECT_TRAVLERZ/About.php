<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravlerZ</title>
    <!-- font awesome cdn link CDN = https://cdnjs.com/libraries/font-awesome -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css ">

    <link rel="stylesheet" href="Style.css">
    <!-- swiper css link from CDN= https://swiperjs.com/get-started -->
   
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>

     <!-- swiper js link  -->
   <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>



</head>
<body>
    
 <!----------------------   HEADER  SECTION  STRAT  ---------------------->

    <section class="header">

    <a href="Home.php" class="logo">TravlerZ</a>

    <nav class="navbar">
        <a href="../MINI_PROJECT_TRAVLERZ/Home.php">home</a>
        <a href="../MINI_PROJECT_TRAVLERZ/About.php">about</a>
        <a href="../MINI_PROJECT_TRAVLERZ/destination.php">destination</a>
        <a href="../MINI_PROJECT_TRAVLERZ/hotels.php">hotels</a>
        <a href="../MINI_PROJECT_TRAVLERZ/restuarants.php">restuarants</a>
        
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

    </section>

<!-----------------------  HEADER  SECTION  END  ------------------------>

<div class="heading" style="background:url(images/About.jpg) no-repeat">
   <h1>about us</h1>
</div>

<!-- about section starts  -->

<section class="about">

   <div class="image">
      <img src="images/holi.jpeg" alt="">
   </div>

   <div class="content">
      <h3>why choose us?</h3>
      <p>It’s the trip of a lifetime, and it’s important to select the right tour company – one that makes sure you leave with special memories, incredible stories and life long friends.</p>
      <p>Quality over quantity is our calling card, we research all the options and present to you only the very best that we can find. We only sell what we can (and do).</p>
      <div class="icons-container">
         <div class="icons">
            <i class="fas fa-map"></i>
            <span>top destinations</span>
         </div>
         <div class="icons">
            <i class="fas fa-hand-holding-usd"></i>
            <span>affordable price</span>
         </div>
         <div class="icons">
            <i class="fas fa-headset"></i>
            <span>24/7 guide service</span>
         </div>
      </div>
   </div>

</section>

<!-- about section ends -->




 <!-- footer section starts  -->

 <section class="footer">

<div class="box-container">


<div class="box">
   <h3>quick links</h3>
      <a href="../MINI_PROJECT_TRAVLERZ/Home.php"> <i class="fas fa-angle-right"></i> home</a>
      <a href="../MINI_PROJECT_TRAVLERZ/About.php"> <i class="fas fa-angle-right"></i> about</a>
      <a href="../MINI_PROJECT_TRAVLERZ/destination.php"> <i class="fas fa-angle-right"></i> destination</a>
      <a href="../MINI_PROJECT_TRAVLERZ/hotels.php"> <i class="fas fa-angle-right"></i> hotels</a>
      <a href="../MINI_PROJECT_TRAVLERZ/restuarants.php"> <i class="fas fa-angle-right"></i> restuarants</a>
      
    </div>
   <div class="box">
      <h3>extra links</h3>
      <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
      <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
      <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
   </div>

   <div class="box">
      <h3>contact info</h3>
      <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
      <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
      <a href="#"> <i class="fas fa-envelope"></i> travlerz1@gmail.com </a>
      <a href="#"> <i class="fas fa-map"></i> Uttar Pradesh, India  </a>
   </div>

   <div class="box">
      <h3>follow us</h3>
      <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
      <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
      <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
   </div>

</div>

<div class="credit"> created by <span> TravlerZ Team </span> | All Rights Reserved |  </div>

</section>

<!-- footer section ends -->


 <!-- swiper js link  -->
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<script src="Script.js"></script>


</body>
</html>