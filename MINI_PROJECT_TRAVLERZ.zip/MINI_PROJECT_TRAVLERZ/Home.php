<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravlerZ</title>
    <!-- font awesome cdn link CDN = https://cdnjs.com/libraries/font-awesome -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css ">

    <link rel="stylesheet" href="Style.css">
    <!-- swiper css link from CDN= https://swiperjs.com/get-started -->
   
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>

     <!-- swiper js link  -->
   <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
   



</head>
<body>
    
 <!----------------------   HEADER  SECTION  STRAT  ---------------------->

    <section class="header">

    <a href="Home.php" class="logo"> 
      TravlerZ
      <nav class="navbar">
        <a href="../MINI_PROJECT_TRAVLERZ/Home.php">home</a>
        <a href="../MINI_PROJECT_TRAVLERZ/About.php">about</a>
        <a href="../MINI_PROJECT_TRAVLERZ/destination.php">destination</a>
        <a href="../MINI_PROJECT_TRAVLERZ/hotels.php">hotels</a>
        <a href="../MINI_PROJECT_TRAVLERZ/restuarants.php">restuarants</a>
        
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

    </section>

<!-----------------------  HEADER  SECTION  END  ------------------------>

<!----------------------- HOME  SECTION  START  ------------------------->

   
<section class="home">

<div class="swiper home-slider">

   <div class="swiper-wrapper">

      <div class="swiper-slide slide" style="background:url(images/Home2.jpg) no-repeat">
         <div class="content1">
            <span>explore new things, discover new places, travel the country </span>
            <h3>travel arround</h3>
            <h3>the country</h3>
            <a href="destination.php" class="btn ">Discover more</a>
         </div>
      </div>

      <div class="swiper-slide slide" style="background:url(images/Home.png) no-repeat">
         <div class="content2">
            <span>explore new things, discover new places, travel the country</span>
            <h3>discover </h3>
            <h3> new places</h3>
            <a href="destination.php" class="btn">discover more</a>
         </div>
      </div>

      <div class="swiper-slide slide" style="background:url(images/Home3.jpg) no-repeat">
         <div class="content3">
            <span>explore new things, discover new places, travel the country</span>
            <h3>make your tour</h3>
            <h3> worthwhile</h3>
            <a href="destination.php" class="btn">discover more</a>
         </div>
      </div>

   </div>

   <div class="swiper-button-next"></div>
   <div class="swiper-button-prev"></div>

</div>

</section>

<!---------------------  HOME  SECTION END  -------------------- -->


<!--------------------- SERVICE SECTION STRAT ----------------------->

<section class="services">

<h1 class="heading-title"> Our Services </h1>

<div class="box-container">

   <div class="box">
      <img src="images/tour.jpeg" alt="">
      <h3>tour guide</h3>
   </div>

   <div class="box">
      <img src="images/hotel.jpeg" alt="">
      <h3>hotels</h3>
   </div>


   <div class="box">
      <img src="images/restuarant.jpeg" alt="">
      <h3>restaurant</h3>
   </div>

   <div class="box">
      <img src="images/camping.jpeg" alt="">
      <h3>camping</h3>
   </div>

</div>

</section>

<!------------------------  SERVICE SECTION END ------------------------->


<!-------------------------HOME ABOUT SECTION START --------------------->

<section class="home-about">

<div class="image">
   <img src="images/img2.jpeg" alt="" height = "400px" width = "400px">
</div>

<div class="content">
   <h3>about us</h3>
   <p> We are here to serve you with are website by suggeseting places, advantures, activities for doing at your vacation trip. We have destinations to choose, 24/7 costumer services,etc </p>
   <a href="about.php" class="btn">read more</a>
</div>

</section>

<!-------------------------HOME ABOUT SECTION END --------------------->


<!------------------------HOME PACKAGE SECTION START --------------------->


<section class="home-packages">

<h1 class="heading-title"> Top Destinations </h1>

<div class="box-container">

   <div class="box">
      <div class="image">
         <img src="images/1.jpg" alt="">
      </div>
      <div class="content">
         <h3>Prem Mandir</h3>
         <p>Prem Mandir is a Hindu temple in Vrindavan, Mathura district, Uttar Pradesh, India. The temple was established by Jagadguru Shri Kripalu Ji Maharaj. <br><br> </p>
         <a href="../MINI_PROJECT_TRAVLERZ/destination.php" class="btn">Explore Temples</a>
      </div>
   </div>

   <div class="box">
      <div class="image">
         <img src="images/lostcafe.jpeg" alt="">
      </div>
      <div class="content">
         <h3>Loft Cafe Restuarant</h3>
         <p>Order Food Online from Loft Cafe in Mandi Bypass,Mathura well known for Restaurants in Mathura.<br><br><br> </p>
         <a href="../MINI_PROJECT_TRAVLERZ/restuarants.php" class="btn">Explore Restuarants</a>
      </div>
   </div>

   <div class="box">
      <div class="image">
         <img src="images/centrum.jpeg" alt="">
      </div>
      <div class="content">
         <h3>Visit Centrum Brijwasi Hotel</h3>
         <p> FMRF+FCQ, and, Bhuteshwar Rd, near New Bus Stand, near New Railway Station, Adarsh Nagar, Manoharpura, Mathura, Uttar Pradesh 281001  </p>
         <a href="../MINI_PROJECT_TRAVLERZ/hotels.php" class="btn">Explore Hotels</a>
      </div>
   </div>

</div>



</section>


<!------------------------HOME PACKAGE SECTION END --------------------->




 <!-- footer section starts  -->

 <section class="footer">

<div class="box-container">

<div class="box">
   <h3>quick links</h3>
      <a href="../MINI_PROJECT_TRAVLERZ/Home.php"> <i class="fas fa-angle-right"></i> home</a>
      <a href="../MINI_PROJECT_TRAVLERZ/About.php"> <i class="fas fa-angle-right"></i> about</a>
      <a href="../MINI_PROJECT_TRAVLERZ/destination.php"> <i class="fas fa-angle-right"></i> destination</a>
      <a href="../MINI_PROJECT_TRAVLERZ/hotels.php"> <i class="fas fa-angle-right"></i> hotels</a>
      <a href="../MINI_PROJECT_TRAVLERZ/restuarants.php"> <i class="fas fa-angle-right"></i> restuarants</a>
      
    </div>
   <div class="box">
      <h3>extra links</h3>
      <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
      <a href="about.php"> <i class="fas fa-angle-right"></i> about us</a>
      <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
   </div>

   <div class="box">
      <h3>contact info</h3>
      <a href="#"> <i class="fas fa-phone"></i> +9027781675 </a>
      <a href="#"> <i class="fas fa-phone"></i> +8006957296 </a>
      <a href="#"> <i class="fas fa-envelope"></i> travlerz1@gmail.com </a>
      <a href="#"> <i class="fas fa-map"></i> Uttar Pradesh, India  </a>
   </div>

   <div class="box">
      <h3>follow us</h3>
      <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
      <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
      <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
   </div>

</div>

<div class="credit"> created by <span> TravlerZ Team </span> | All Rights Reserved |  </div>

</section>

<!-- footer section ends -->


 <!-- swiper js link  -->
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<script src="Script.js"></script>


</body>
</html>