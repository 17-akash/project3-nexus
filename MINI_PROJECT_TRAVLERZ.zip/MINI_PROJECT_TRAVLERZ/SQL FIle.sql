-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2023 at 08:00 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travlerz`
--

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `D_ID` int(11) NOT NULL,
  `image` text NOT NULL,
  `name` text NOT NULL,
  `detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`D_ID`, `image`, `name`, `detail`) VALUES
(1, 'Janambhoomi.jpeg', 'Shri Krishna JanamBhumi Temple', 'This is the birthplace of Lord Krishna. One side of the temple has the place were Krishna ji was born, second has the deities.'),
(2, 'bihari ji.jpeg', 'Shri Banke Bihari Ji Mandir', 'Banke Bihari Temple is a Vaishnavite Hindu temple situated in the town of Vrindavan, Mathura district of Uttar Pradesh, India.'),
(3, 'Radha rani temple.jpeg', 'Shri Radha Rani Temple', 'Radha Rani Temple is originally believed to be established by King Vajranabh (great-grandson of Krishna) around 5000 years ago.'),
(4, 'Scon Temple.jpeg', 'Isckon Temple', 'Sri Krishna Balrama Temple is acknowledged for being the first temple constructed by the International Society for Krishna Consciousness (ISKCON).'),
(5, 'vaishno_devi.jpeg', 'Vaishno Devi Dham Mandir', 'Vaishno Devi Dham in Mathura, popularly known as Ma Vaishno Devi Mandir is dedicated to Ma Vaishno Devi who is believed to grant boons to her devotees.'),
(6, 'chandrodaya temple.jpeg', 'Chandrodaya Mandir', 'Vrindavan Chandrodaya Mandir is a temple under early stages of construction at Vrindavan, Mathura, India.'),
(7, 'Prem Mandir.jpg', 'Prem Mandir', 'Prem Mandir (lit. The Temple of Divine Love) is a Hindu temple in Vrindavan, Mathura district, Uttar Pradesh, India. '),
(8, 'Shri-Priyakant-Ju-Temple-Vrindavan.jpg', 'Shri Priyakant Ju Temple', 'This temple dedicated to Lord Krishna is a beautifully styled structure that appears to look as if it sits on a lotus.'),
(9, 'Raman Reti Temple.jpeg', 'Raman Reti', 'Raman Reti is the sand in which Lord Krishna played as a child. In more recent times, about 200 years ago, the famous Saint, Swami Gyandasji did a severe penance at Raman reti for 12 years.'),
(10, 'Nidhivan Temple.jpeg', 'NidhiVan', 'Probably one of the best places to visit in Vrindavan, Nidhivan Temple is a treasure trove for both pilgrims and nature lovers. '),
(11, 'Shri Rangji Mandir.jpeg', 'Shri Rangnath ji Mandir', 'The largest temple in Vrindavan, Shri Rangji Mandir has a Dravidian style of architecture built in the year 1851.'),
(12, 'Gopi Nath Temple.jpeg', 'Radha Gopinath Mandir', 'Resembling the temple structure of the Sri Madan Mohan Temple, Gopi Nath Temple is a renowned spiritual place in Vrindavan.');

-- --------------------------------------------------------

--
-- Table structure for table `destination_details`
--

CREATE TABLE `destination_details` (
  `dest_id` int(11) NOT NULL,
  `d_name` text NOT NULL,
  `d_address` text NOT NULL,
  `d_timing` text NOT NULL,
  `d_details` text NOT NULL,
  `d_image1` text NOT NULL,
  `d_image2` text NOT NULL,
  `d_image3` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destination_details`
--

INSERT INTO `destination_details` (`dest_id`, `d_name`, `d_address`, `d_timing`, `d_details`, `d_image1`, `d_image2`, `d_image3`) VALUES
(1, 'Shri Krishna JanamBhumi Temple', 'Janam bhoomi Marg, Janam Bhumi, Mathura, Uttar Pradesh 281001', 'Monday-Sunday  4–10:45 pm', 'Shri Krishna Janmabhoomi holds such a    special place in the minds and hearts of Hindus because it is believed to be \r\n            birthplace of Lord Krishna. The birth of Lord Krishna is one of the most interesting episodes of Bhagavata Purana \r\n            and Mahabharata. He was born in Mathura which was then ruled by the tyrant King Kansa. Certain fortune tellers told \r\n            Kansa that he would meet his death at the hands of the eighth child of Devaki.\r\nActing on the prediction, he imprisoned Shri Vasudeva and Mata Devaki and arranged to have all of her children killed. \r\n            Lord Krishna was born to Devaki in the eight month of her pregnancy at midnight. According to a miracle brought about \r\n            by Lord Vishnu, all the doors of the prison were left unlocked that night. After his birth, Vasudeva carried the newborn\r\n             in a basket across the river Yamuna.\r\n Shri Krishna Janmabhoomi Temple, which is counted among the most visited religious destinations in India, \r\n            is believed to have been constructed about five times. Mythological sources state that this temple was first constructed\r\n            by the great grandson of Lord Krishna, Vajranabha, about 5000 years ago. Thereafter, it was rebuilt and underwent \r\n            modifications under Chandragupta Vikramaditya, Raja Dhrupet Dev Janjua and Raja Veer Singh Bundela of Orchha. \r\n            Saint Chaitanya Mahaprabhu, founder of the Vaishnava sect of Bhakti yoga, is also believed to have visited the\r\n            temple in the 16th century.\r\n The city of Mathura came under the rule of British in 1803, and in 1815, the temple’s land was auctioned by \r\n              the British East India Company. The land was purchased by Raja Patnimal of Benares but he could not build the temple. \r\n              Finally, it was constructed by Pandit Madan Mohan Malviya who received financial assistance from the famous industrialist,\r\n               Jugal Kishore ji Birla. Finally, with combined efforts, the temple’s construction was completed in February, 1982. \r\n              ', 'janambhumi1.jpeg', 'Janambhoomi.jpeg', 'janambhumi3.jpg'),
(2, 'Shri Banke Bihari Ji Mandir', 'Goda Vihar, Vrindavan, Uttar Pradesh 281121', 'Monday- Sunday  8:30 am–1 pm, 4:30–8:30 pm', 'Banke Bihari Temple is a Vaishnavite Hindu temple situated in the town of Vrindavan, Mathura district of Uttar Pradesh, India. \r\n            The temple is dedicated to Banke Bihari who is believed to be the combined form of Radha and Krishna. \r\n            Banke Bihari was originally worshipped at Nidhivan, Vrindavan. \r\n            Later, when Banke Bihari temple was constructed around 1864, the icon of Banke Bihari was moved to new temple. \r\nThe icon of Radha Krishna\'s united form stands in the Tribhanga posture. \r\n            Swami Haridas originally worshipped this devotional image under the name of Kunj-Bihari (\"one who enjoys in the groves (Kunj) of Vrindavan\").\r\n According to Srī Brahma-samhita (verse 5.31), Brahma says the following about Krishna:- \r\n\r\n            \"I worship Govinda, the primeval Lord, round whose neck is swinging a garland of flowers beautified with the moon-locket, whose two hands are adorned with the flute and jewelled ornaments,\r\n             who always revels in pastimes of love, whose graceful threefold-bending form of Syamasundara is eternally manifest.\r\nBanke Bihari Temple was established by Swami Haridas (Lalita Sakhi in Dvapara Yuga), a guru of the famous singer Tansen. \r\n              Once at the request of his disciples Swami Haridasji sang the following verse in Nidhivan, Vrindavan \"Mai ri Sahaj Jori pragat Bhai \r\n              Ju rang ki gaur Syam ghan damini jaisen. Pratham hun ahuti ab hun aagen hun rahihai na tarihai taisain.. Ang ang ki ujraii sugharaii chaturaii sunderta aisain... Shri Haridas ke swami syama kunjbihari sam vais vaisain..\" On singing the verse, the Celestial couple Shyama-Shyam (Radha Krishna) appeared in front of him and his devotees. At the request of Shri Swamiji, the couple merged into one and the stone image of Banke Bihari appeared there (the same image is seen in the temple). \r\n              The image was established in Nidhivan.\r\n               The stone image of Bihariji installed in Shri Banke Bihari Mandir is the one granted to Swami\r\n                Haridas by the celestial couple Shyama-Shyam themselves. Submitting to the desire of devotees, \r\n                The Lord appeared in person with his divine consort and left-back a black charming image before disappearing.\r\n               \r\n           ', 'bihariji1.jpeg', 'bihariji2.jpeg', 'bihariji3.jpeg'),
(3, 'Shri Radha Rani Temple', 'Shree Ji Mandir, bramachal parbhat, Barsana, Uttar Pradesh 281405', 'Monday - Sunday 4:45–6 am, 8 am–12:45 pm, 4:30–8:30 pm\r\n               ', 'Shri Radha Rani Temple, also called Shriji (Shreeji) Temple and Shri Laadli Lal Temple, \r\n            is a historical Hindu temple, located in Barsana in Mathura district, Uttar Pradesh, India.The temple is dedicated to the goddess Radha.[2] The main deities of the temple are Radha Krishna who are worshipped\r\n             together in the form of Shri Laadli Lal which means beloved daughter and son of the town.\r\n The temple is stretched on the top of Bhanugarh hills, which is about 250 meters in height.[1] The temple attracts huge crowd of devotees and tourists visiting temple \r\n            from across the world for its most popular festivals - Radhashtami and Lathmar Holi.\r\nRadha Rani Temple is originally believed to be established by King Vajranabh (great-grandson of Krishna) around 5000 years ago. \r\n            The temple is said to be in ruins; the icons were rediscovered by Narayan Bhatt (a disciple of Chaitanya Mahaprabhu) and a temple was built in 1675 AD by Raja Veer Singh. Later, the present structure \r\n            of temple was built by Narayan Bhatt with the help of Raja Todarmal, one of the governors in the Akbar\'s court.\r\nThere is also a popular legend associated with the temple. According to it, Krishna\'s father Nanda and \r\n              Radha\'s father Vrishbhanu were close friends. While Nanda was head of Gokula, Vrishbhanu was head of Rawal.\r\n               However, fed up with the atrocities of Mathura\'s king Kamsa, both of them with their people shifted to \r\n               Nandgaon and Barsana. Nanda made Nandishvar hill his home and Vrishbhanu made Bhanugarh hill his permanent \r\n               abode, which also ultimately became the abode of Radha. Presently, in both the twin towns of Barsana and\r\n                Nandgaon, there stands the historical temples dedicated to Radha and Krishna on the peak of Nandishvar and\r\n                 Bhanugarh hills respectively. While Nandgaon temple is called the Nand Bhawan, \r\n              Barsana temple is named after Radha, called Radha Rani temple or Shriji (Shreeji temple).', 'radhe1.jpeg', 'radhe2.jpg', 'Radha rani temple.jpeg'),
(4, 'Isckon Temple', 'ISKCON Vrindavan,\r\n\r\n                Krishna Balaram Mandir\r\n\r\n                Bhaktivedanta Swami Marg, Raman Reti,\r\n\r\n                Vrindavan, Uttar Pradesh-281121', 'Monday - Sunday 4:10am- 8:15pm', 'Sri Sri Krishna Balaram Mandir, also called ISKCON Vrindavan, is one of the major\r\n             ISKCON temples in the world. It is a Gaudiya Vaishnava temple located in the city \r\n             of Vrindavan, Mathura district, in the Indian state of Uttar Pradesh.\r\n             The temple is dedicated to the Hindu gods Krishna and Balarama. \r\n            The other deities of temple are Radha Krishna and Gauranga Nityananda.\r\nSri Krishna Balrama Temple is acknowledged for being the first temple constructed by the \r\n            International Society for Krishna Consciousness (ISKCON). Built in 1975 by the \r\n            ISKCON cult, the foundation of the shrine was laid by Swami Prabhupada (founder of ISKCON) himself.', 'i2.jpeg', 'i1.jpeg', 'i3.jpeg'),
(5, 'Vaishno Devi Dham Mandir', 'Bhaktivedanta Swami Marg, Vrindavan, Uttar Pradesh 281121', 'Monday - Sunday  6:00 am – 1:00 pm\r\n                    ,4:00 pm – 8:00 pm', 'A temple town like none other, Vrindavan boasts of few of the best temples in Uttar Pradesh, \r\n            adorned with exquisite craftsmanship and beautifully carved deities. With a \r\n            throng of temples to visit in Mathura and Vrindavan, \r\n            one of the most revered temples is the Vaishno Devi temple in Vrindavan.\r\n            Vaishno Devi is an incarnation of Devi, the Hindu Mother Goddess. \r\n            She is also known as Trikuta, Ambe, Mata Rani, and Vaishnavi. \r\n            The phrases \"Maa\" and \"Mata\" are frequently associated with Vaishno Devi. \r\n            The combined powers of Parvati, Lakshmi, and Saraswati created Vaishno Devi. \r\n            It is one of the best temples to visit in Vrindavan.\r\nVaishno Devi temple shows work with a great deal of care and handwork. \r\n            And Sh. J C Chaudhry\'s vision, with the assistance of experienced architects from\r\n             Design Well India (P) Ltd., where Mr Arun Verma served as chief architect, as well \r\n             as young and brilliant engineers, made the temple\r\n            This temple\'s characteristic feature is its massive statue of Maa Vaishno Devi.\r\n             It is brilliantly decorated and dressed with a red saree clubbed with trinkets \r\n             and weapons of the goddess. These signify her power and strength to fight evil, \r\n             elegantly sitting on her regal carrier, Lion. Next to it is a massive statue of \r\n             Lord Hanuman, seated with one folded leg and folded hands, waiting for Maa\'s blessings.\r\n            The Vaishno Devi Dham in Vrindavan has an attached dispensary and library for pilgrims.\r\n             In addition, it includes two dharamshalas to accommodate visiting devotees. \r\n             The central hall is for meditation, and the yoga hall is adjacent to it. \r\n             The location of Vaishno Devi Dham is auspicious and associated with Lord Krishna\'s growing years\r\n            The most astounding thing is that all of these massive statues are present \r\n            on the temple\'s roof. The shrine is unmissable for any tourist to Vrindavan\r\n            Because of its massive size, it is visible from afar. A total of 1,700-tonne\r\n             mass is present at the foundation level, along with the Raft Foundation at a \r\n             depth of 4.0 metres below ground level. This is to provide a platform and \r\n             stability for the gigantic statues. Furthermore, the Maa Vaishno Devi statue, \r\n             along with her Lion, ornaments and other things required around 400 tonnes of steel and concrete\r\n            With the assistance of sophisticated software and dynamic analysis, these\r\n             statues are also tested against earthquakes and other major devastation.\r\n              It\'s worth noting that the Maa Vaishno Devi Murti (statue) from the ground \r\n              is 141 feet. The Lion\'s height from the floor is approximately 35 feet. \r\n              Lord Hanuman\'s statue stands 32 feet tall, and his Gadda is 26 feet long.', 'v1.jpeg', 'v2.jpeg', 'v3.jpeg'),
(6, 'Chandrodaya Mandir', 'Akshaya Patra Temple Campus, Bhaktivedanta Swami Marg, Vrindavan, Uttar Pradesh 281121', 'Monday - Sunday  7:15 am – 1:00 pm\r\n                    ,4:15 pm – 8:15 pm', 'In 1972, Srila Prabhupada, the founder and Acharya of ISKCON spoke about the principle of Yukta Vairāgya \r\n            right in front of the Bhajan Kutir (a simple and austere dwelling of an ascetic primarily \r\n            intended to perform his spiritual activities like chanting Krishna\'s names, writing and teaching)\r\n             of Sri Rupa Goswami\r\n             to his dozen or more western disciples who were accompanying him on a visit to Vrindavan, India. He said: <br>\r\n            Just like we have got a tendency to construct a skyscraper building. As in your country, you do. So you should not attached to the skyscraper building, but you can utilize the tendency by constructing a big temple like skyscraper for Krishna. In this way, you have to purify your material activities.\r\n             — Srila Prabhupada\'s lecture in Vrindavan, 29 October 1972\r\n            Inspired by this vision and statement of Srila Prabhupada, the devotees of \r\n            ISKCON Bangalore, who are strictly adhering to prabhupadas instructions conceived\r\n             the Vrindavan Chandrodaya Mandir project to build a skyscraper temple for Lord Sri Krishna.\r\n The foundation stone laying ceremony of Chandrodaya temple in Mathura district was done \r\n            on 16 March 2014, on the eve of the auspicious occasion of Holi.\r\nVrindavan Chandrodaya Mandir is a temple under early stages of construction at Vrindavan, Mathura, India. \r\n            As planned, it will be the tallest religious monument in the world.[1][2] At its potential cost of ₹700 crore\r\n             (US$88 million) it is likely to be one of the most expensive temples in world. The temple has been planned \r\n             by ISKCON Bangalore.[3] The planned effort includes the temple rising to a height of about 700 feet \r\n             (210 meters) or 70 floors) and a built-up area of 540,000 sq. ft. (~50,000 sq. m.).\r\n             The project is set in 62 acres of land and includes 12 acres for parking and a helipad.', 'c1.jpeg', 'c2.jpeg', 'c3.jpeg'),
(7, 'Prem Mandir', 'Sri Kripalu Maharaj Ji Marg, Raman Reiti, Vrindavan, Uttar Pradesh 281121', 'Monday - Sunday  8:30 am–12:30 pm, 4:30–8:30 pm', 'Prem Mandir (lit. The Temple of Divine Love) is a Hindu temple in Vrindavan, Mathura district, \r\n            Uttar Pradesh, India. The temple was established by Jagadguru Shri Kripalu Ji Maharaj \r\n            (the fifth Original Jagadguru).It is maintained by Jagadguru Kripalu Parishat, an international \r\n            non-profit, educational, spiritual, charitable trust. The complex is on a 55-acre site on the \r\n            outskirts of Vrindavan. It is dedicated to Radha Krishna and Sita Ram. Radha Krishna are on the first\r\n             level and Sita Ram are on the second level. Different Leelas of Shri Krishna and Rasik \r\n             saints are depicted all over the wall of the main temple.\r\nConstruction began in January 2001 and the inauguration ceremony took place from \r\n            15 to 17 February 2012.The temple was opened to the public on 17 February. \r\n            The cost was 150 crore rupees ($23 million).The presiding deity are Shri Radha Govind\r\n             (Radha Krishna) and Shri Sita Ram. A 73,000 square feet, pillar-less, dome shaped satsang\r\n              hall is being constructed next to the Prem Mandir, which will accommodate 25,000 people at a time.\r\n               Surrounded by beautiful gardens and fountains, the temple complex has life-size \r\n               depictions of four leelas of Shri Krishna – Jhulan leela, Govardhan leela, Raas leela and\r\n                Kaliya Naag leela.\r\nIt is sister temple of Bhakti Mandir which was opened in 2005 and another sister\r\n             temple which is known as Kirti Mandir, Barsana opened in 2019.\r\nThe foundation stone was laid by Jagadguru Shri Kripalu Ji Maharaj in the presence of thousand devotees on 14 January 2001. \r\n            The structure took around 12 years to construct, involving around 1000 artisans.\r\n\r\n            The Vrindavan site was developed by Kripalu Ji Maharaj, whose main ashram was in Vrindavan.\r\n            He dedicated the gift of love to Shri Vrindavan Dham.\r\n            \r\n            Prem Mandir is constructed entirely of Italian marble. The total dimensions of the temple including\r\n             its flag is 125 ft. high, 190 ft. long and the 128 ft. \r\n             wide raised platform serves as the seat of the two-storeyed white monument.', 'p1.jpeg', 'p2.jpeg', 'p3.jpeg'),
(8, 'Shri Priyakant Ju Temple', 'HJ7Q+JCR, Rina Rd, Raman Reiti, Vrindavan, Uttar Pradesh 281121', 'Monday-Sunday 8:30 am–12:00 pm, 4:00–9:00 pm', 'Shri Priyakantju Temple is dedicated to Lord Krishna and the temple ensconced the beautiful\r\n             and attractive deities of Lord Krishna and Radha.  The theme of the construction of this temple is Radha Krishna, \r\n            Radharani is in the form of Priya Ji and Bhagwan Shri Krishna takes that of Kant ju giving darshan to the devotees.\r\n             \r\n             The temple is situated in the holy city of Vrindavan in Mathura district, Uttar Pradesh. \r\n             Built on the structure symbolizing lotus flower, the temple is almost 125 feet high.  \r\n             The temple is built along roadside and is far above the ground level. The temple is covered \r\n             with ponds from both sides in which fountains are also fitted. Temples of Lord Ganesh, Hanuman \r\n             and Lord Shiva are built at the four corners of the temple. Makrana marble from Rajasthan is used\r\n              in the construction of the temple. The temple reflects a renaissance in the ancient Indian art and architecture.\r\nThe Vishwa Shanti Charitable Trust resolved to build the Priyakantju temple in 2007. \r\n            Shri Priyakant ju temple was established by Shri Devikinandan Thakur, \r\n            the President of the Vishwa Shanti Charitable Trust in 2009 and it took almost seven years to complete. \r\n            The first phase of temple construction started in June 2012. Priyakantju Temple was opened for public in\r\n             February 8, 2016. The temple was inaugurated by Sri Kaptan Singh Solanki, Governor of Haryana.\r\n              Lakhs of devotees participated in the inauguration function.\r\n             ', 'priya2.jpeg', 'priya1.jpeg', 'priya3.jpeg'),
(9, 'Raman Reti ', 'Radha Raman Bagicha, Parikrama Marg, Tarash Mandir Colony, Vrindavan, Uttar Pradesh 281121', 'Whole Day', 'Situated in Gokul, a few kilometers away from Mathura is this incredible place called Raman\r\n             Van or Raman Reti―whose sacred sands (reti) are redolent with the stories of a bygone era \r\n             when Lord Krishna frequented to engage in divine plays (raman) with his brother, Balarama \r\n             and his cowherd friends. This is also the place he chose to meet his love, Radha before embarking\r\n              on their journey to Vrindavan together. Raman Reti today is a sandy locale sprawled in a spacious\r\n               compound complete with a deer sanctuary, a couple of beautiful temples and a relaxing area for \r\n               ascetics, saints and pilgrims alike. Besides paying reverence, spend some time simply ambling \r\n               around in the complex―try to bask in the pastimes of Lord Krishna treasured in the sands of \r\n               Raman Reti.Adjacent to Raman Reti is Karshni Ashram, a famous Ashram housing the ancient Raman\r\n                Bihariji Temple. Dedicated to the 18th century Saint Gyandasji, the temple houses the deity of\r\n                 Lord Krishna in the exact form as was revealed to the saint as a blessing for his strong\r\n                  austerities to please the Lord. \r\n            A visit to this famed temple must be on your itinerary if you are stepping in this mystical region.</p> <br>\r\n            ', 'r1.jpeg', 'r2.jpeg', 'r3.jpeg'),
(10, 'NidhiVan', 'Gopinath Bagh, Vrindavan, Uttar Pradesh 281121', 'Monday - Sunday 6 am - 8 pm', ' Nidhivan (Hindi: निधिवन) \"Tulsi Forest \" is one of the sacred sites of Vrindavan, \r\n            situated in the Mathura district, Uttar Pradesh, India. It is considered as the most prominent site dedicated \r\n            to the pastimes of Hindu deities Radha and Krishna and their companions gopis. It is the common\r\n             belief among devotees that Nidhivan still witnesses the raslila (dance)\r\n             of Radha Krishna during the night time and thus, nobody is allowed to stay \r\n             inside the premises of Nidhivan at night.\r\nThe site has numerous Tulsi (Basil) trees which are short in height but found in pairs \r\n            and have entangled trunks. Besides Tulsi plants, the premises also houses a temple called Rang Mahal, \r\n            where it is believed that Radha and Krishna spend their night after raslila. Within the premises, \r\n            there is also another temple called Bansichor Radha temple, where Radha has stolen the flute of Krishna, \r\n            a shrine dedicated to Swami Haridas who with his complete devotion made the idol of Banke Bihari appeared,\r\n             Raslila sthali where raaslila is performed and \r\n            Lalita kund which was believed to be made by Krishna himself, when gopis asked for water amidst of Raslila.\r\n            ', 'n1.jpeg', 'n2.jpeg', 'n3.jpeg'),
(11, 'Sri Rangnath ji Mandir', 'Brahmakund, Rangnath mandir, Goda Vihar, Vrindavan, Uttar Pradesh 281121', 'Monday - Sunday  5am-12pm, 3pm-8pm', ' Sri Rangji Temple or Rangnath ji Temple is one of the largest and the only temple built in Dravidian style in \r\n            Vrindavan.\r\n            Vrindavan has always been the centre of faith and devotion because \r\n            of its association with Lord Krishna and Radha Rani. \r\n            This devotion has been the driving force \r\n            behind the construction of temples throughout history.  Built in 1851, by Seth Govind Das ji and Seth RadhaKrishna ji under the guidance of Shri \r\n            Rangdeshik Swami ji, Shri Rang ji Temple is dedicated to Lord Shri Goda - Rangamannar. \r\n            Goda or Andal was a famous 8th century \r\n            Vaishnava saint who had composed “Thiruppavai” which is a set of Tamil devotional religious hymns.\r\n            \r\n            As per the belief, Goda devi had fasted and prayed to attain Lord Rangamannar or Lord Vishnu. \r\n            Lord Rangamannar or Lord Ranganatha who is none other than Lord Krishna fulfilled her wish by \r\n            becoming her bridegroom. In the temple, Lord Ranganatha is worshipped as the bridegroom with a \r\n            walking stick with Andal on his right.\r\n            Shri Ranganath ji temple is inspired from Ranganathswamy temple at Srirangam in Tamil nadu.\r\n             It mesmerises you with an amalgamation of South Indian and North Indian traditions and influences.', 'rang1.jpeg', 'rang2.jpeg', 'rang3.jpeg'),
(12, 'Radha Gopinath Mandir', 'Parikrama Marg, Keshi Ghat, Vrindavan, Uttar Pradesh 281121', 'Monday - Sunday   5:00AM- 8:PM', 'Radha Gopinath is considered to be one among the oldest temple in vrindavan located at the bank of Yamuna Ji.\r\n            Vrajanabha, Lord Krishna\'s great-grandson, installed the original Gopinath Deity in Vrindavan over\r\n             five-thousand years ago. About five-hundred years ago, Paramananda Bhattacharya discovered the Deity\r\n              in the earth at Banshivat on the banks of the Yamuna. Madhu Pandit Goswami, a disciple of Shri Gadadhar\r\n               Pandit close associate of Chaitanya Mahaprabhu, worshiped the Gopinath Deity.\r\n            Once, Nityananda Prabhu’s wife Jahnava thakuranee came to Vrindavan. As she was having darshan\r\n             of Shri Radha-Gopinath, she thought that the deity of Radhika was too small and that‚ if Radhika\r\n              had been a little taller, the Couple would look much more beautiful. Jahnava thakurane returned\r\n               to her residence after beholding the evening ceremony. That night, in a dream, Shri Gopinath \r\n               asked Jahnava to arrange for a taller deity of Radhika. She received similar instructions from \r\n               Radharani, and had a deity of Her made that was a more appropriate size for the deity of Gopinath.\r\n                The book Bhakta-mala describes that at the time of Jahnava thakurane’s disappearance, she revealed\r\n                 her own deity and established herself in it. She instructed the priests to install the deity of her\r\n                  in the chamber of Shri Gopinath. When this deity arrived at the temple of Gopinath in Vrindavan, \r\n                  the priests hesitated to install her along side Shri Gopinatha. At that time, Gopinathje Himself \r\n                  instructed the priests, “Do not hesitate. This is My beloved Anang Manjaree. Place her on My left\r\n                   and Radhika on My right.” And so it came to be that Jahnava stands on Shri Gopinath’s left side \r\n                   and Radhika stands on His right. Jahnava thakuranee is seated on the left side of Gopinath, and Lalita Sakhé \r\n            and a small deity of Radhika are seated on His right. \r\n            Near the new temple to the east is the samadhi of Madhu Pandita.', 'gopi1.jpeg', 'gopi2.jpeg', 'gopi3.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `H_ID` int(11) NOT NULL,
  `h_image` text NOT NULL,
  `h_name` text NOT NULL,
  `h_detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`H_ID`, `h_image`, `h_name`, `h_detail`) VALUES
(1, 'nidhivan hotel.jpg', 'Nidhivan Sarovar Portico Hotel', 'Situated 4 km from the historic and magnificent Banke Bihari ji Temple, Nidhivan Hotels & Resorts offers a 24-hour front desk and free Wi-Fi throughout the property. The property also features access facilities for the physically challenged, a salon on premise as well as free parking facilities..'),
(2, 'radhakuunj hotel.jpg', 'Shri Radha Nikunj Hotel', 'Located in Vrindāvan,Hotel Shri Radha Nikunj at Prem Mandir provides accommodation with a fitness centre, free private parking, a garden and a restaurant. This 3-star hotel offers a concierge service and a tour desk. The accommodation features a 24-hour front desk, airport transfers, room service and free WiFi throughout the property..'),
(3, 'hotel basera.jpg', 'Hotel Basera Brij Bhoomi Vrindavan', 'Located just 800 m from the sacred Bankey Bihari Temple and 1 km from the Vrindavan Bus Station, Hotel Basera Brij Bhoomi Vrindavan provides 24-hour front desk for the convenience of the guests.'),
(4, 'homestay hotel.jpg', 'Radha Krishna Bhawan Hotel', 'Set in Vrindāvan, the recently renovated Radha Krishna Bhawan, Homestay offers accommodation 47 km from Bharatpur Railway Station and 13 km from Mathura Railway Station. The air-conditioned accommodation is 49 km from Wildlife SOS. The homestay has family rooms.'),
(5, 'ashram hotel.jpg', 'Shree Krishna Bhakti Ashram', 'Shree Krishna Bhakti Ashram is a recently renovated guest house in Vrindāvan, where guests can make the most of its garden and shared lounge. This property offers access to a terrace, free private parking and free WiFi.'),
(6, 'guesthouse hotel.jpg', 'MVT Guesthouse Hotel', 'Boasting a garden, terrace, restaurant and free WiFi, MVT Guesthouse & Restaurant is set in Vrindāvan, 47 km from Bharatpur Railway Station and 12 km from Mathura Railway Station. The accommodation offers room service, a 24-hour front desk and currency exchange for guests.'),
(7, 'brijdarshan hotel.jpg', 'Brij Darshan Hotel', 'Situated in Vrindāvan, Brij Darshan features accommodation with a garden, free private parking and a terrace. Located around 47 km from Wildlife SOS, the hotel is also 48 km away from Lohagarh Fort. The property is non-smoking and is set 11 km from Mathura Railway Station.'),
(8, 'holiday hotel.jpg', 'Shridham Holiday Vrindavan', 'A sustainable apartment in Vrindāvan, Shridham Holiday Vrindavan offers outdoor fireplace, parking on-site and sports facilities. Among the facilities of this property are a restaurant, a 24-hour front desk and a lift, along with free WiFi. Guests can make use of the children\'s playground or the picnic area, or enjoy views of the mountain and garden.'),
(9, 'ammaji hotel.jpg', 'Ammaji Hotel', 'Located in Vrindāvan, Ammaji provides accommodation with a garden, free private parking and a restaurant. This 3-star hotel offers room service and a 24-hour front desk. Mathura Railway Station is 12 km from the hotel and Wildlife SOS is 48 km away.'),
(10, 'ananddham hotel.jpg', 'Hotel Shree Anand Dham', 'Situated in Vrindāvan, within 11 km of Mathura Railway Station, Hotel Shree Anand Dham features accommodation with a restaurant and as well as free private parking for guests who drive. Featuring a terrace, the 3-star hotel has air-conditioned rooms with free WiFi, each with a private bathroom. The accommodation provides room service and a 24-hour front desk for guests.'),
(11, 'vrindwoods hotel.jpg', 'The Vrindwoods Hotel', 'Situated in Vrindāvan, The Vrindwoods offers accommodation with free bikes, free private parking, an outdoor swimming pool and a garden. This 4-star hotel offers room service and a 24-hour front desk. Certain units at the property feature a terrace with a city view.'),
(12, 'comfortSKD hotel.jpg', 'Avexia Comfort SKD Hotel', ' Avexia Comfort SKD Vrindavan FULLY VACCINATED STAFF is set in Vrindāvan and features a terrace. Among the facilities of this property are a restaurant, a 24-hour front desk and room service, along with free WiFi throughout the property. The hotel has newspapers and a fax machine and photocopier that guests can use.');

-- --------------------------------------------------------

--
-- Table structure for table `hotels_details`
--

CREATE TABLE `hotels_details` (
  `ho_id` int(11) NOT NULL,
  `ho_name` text NOT NULL,
  `ho_address` text NOT NULL,
  `ho_timing` text NOT NULL,
  `ho_phone1` text NOT NULL,
  `ho_phone2` text NOT NULL,
  `ho_details` text NOT NULL,
  `ho_image1` text NOT NULL,
  `ho_image2` text NOT NULL,
  `ho_image3` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotels_details`
--

INSERT INTO `hotels_details` (`ho_id`, `ho_name`, `ho_address`, `ho_timing`, `ho_phone1`, `ho_phone2`, `ho_details`, `ho_image1`, `ho_image2`, `ho_image3`) VALUES
(12, 'Avexia Comfort SKD Hotel', 'Plot No 16, khasra No 56, situated at mauza vrindavan Bangar Tehsil and District Mathura UP', '24 X 7', '+91 895 863 7000', '91 745 502 7001', ' Avexia Comfort SKD Vrindavan is a good choice for travellers looking for a 3 star hotel in Vrindavan. It is located in Raman Reiti. Hotel is rated 3.8 out of 5, which is considered as good. Some of the popular transit points from Avexia Comfort SKD Vrindavan are New Bus Stand (11.2 kms) and Old Bus Stand (11.4 kms). The Hotel is in proximity to some popular tourist attractions and other places of interest in Vrindavan. Some of the tourist attractions near Avexia Comfort SKD Vrindavan Ashta Sakhi Temple (1.1 kms), Vrindavan-Chandra Mandir (1.5 kms), Banke Bihari Temple (1.6 kms), Prem Mandir (1.7 kms), Imlitala Mandir (1.8 kms), Radhavallabh Temple (1.8 kms) and Jaipur Temple (2.3 kms).\r\n\r\nFrom all the 3 Star hotels in Vrindavan, Avexia Comfort SKD Vrindavan is very much popular among the tourists. A smooth check-in/check-out process, flexible policies and friendly management garner great customer satisfaction for this property. The Hotel has standard Check-In time as 01:00 PM and Check-Out time as 11:00 AM. It is a couple-friendly property, hence it is absolutely safe for unmarried couples to stay here. The Hotel is also certified as a Gostay hotel which comes with a money-back guarantee. Being a Gostay property, it ensures free wifi, AC, TV and good hygiene.\r\n\r\n        ', 'Avexia Comfort SKD Hotel img1.png', 'Avexia Comfort SKD Hotel img2.png', 'Avexia Comfort SKD Hotel img3.png'),
(7, 'Brij Darshan Hotel', 'Krishna krast Omaxe Eternity vrindavan Uttar Pradesh, 281121 Vrindāvan, India ', '24X7', '+91 99856 22356', '+91 99856 22357', 'Situated in Vrindāvan, 46 km from Bharatpur Railway Station, Brij Darshan features accommodation with a garden, free private parking and a terrace. Located around 47 km from Wildlife SOS, the hotel is also 48 km away from Lohagarh Fort. The property is non-smoking and is set 11 km from Mathura Railway Station.\r\nThe rooms in the hotel are fitted with a kettle. At Brij Darshan rooms are fitted with a balcony, a private bathroom and a flat-screen TV.\r\n\r\nThe nearest airport is Agra Airport, 65 km from the accommodation.\r\n', 'Brij Darshan Hotel img1.jpg', 'Brij Darshan Hotel img2.jpg', 'Brij Darshan Hotel img3.jpg'),
(3, 'Hotel Basera Brij Bhoomi Vrindavan', 'Atalla Chungi Parikrama Marg, Atalla Chungi Rd, Vrindavan, Uttar Pradesh 281121, Vrindavan , 281121', '24X7', '+91 895 863 7000', '+91 745 502 7001', 'Conveniently located, Hotel Basera Brij Bhoomi offers comfortable accommodation to its guests.\r\n\r\nSituated at a walking distance from Banke Bihari Mandir, Hotel Basera Brij Bhoomi offers complimentary breakfast and free Wi-Fi access to its guests. Arranged over 4 floors, the hotel in Vrindavan has a total of 34 well-appointed rooms. Rooms include conveniences like air conditioning, flat-screen television, safe, desk, refrigerator, wake-up service and bathroom with shower and free toiletries. Hotel Basera Brij Bhoomi offers services like room service, laundry, 24-hour power backup, housekeeping, ironing, doctor on call and 24-hour security. 24-hour front desk, concierge, currency exchange, travel counter, conference room, business center, banquet facility, wheelchair accessibility, airport transportation, car rental and valet parking are few of the facilities available within the premises. Places of interest and travel hubs in Vrindavan include Vrindavan Railway Station (1.5 km) and Vrindavan Bus Stand (1.5 km), Keshi Ghat (3 km) and ISKCON Vrindavan (2 km). The closest airport to this property is The property also has an in-house restaurant. What people love the most about this property is its great location and hospitality.\r\n', 'Hotel Basera Brij Bhoomi img1.jpg', 'Hotel Basera Brij Bhoomi img2.jpg', 'Hotel Basera Brij Bhoomi img3.jpg'),
(10, 'Hotel Shree Anand Dham', 'Krishna krast Omaxe Eternity vrindavan Uttar Pradesh, 281121 Vrindāvan, India ', '24X7', '+91(838)4890590', '+91 745 226 3692', ' It\'s a small budget luxury hotel located in the heart of the city and near to all major attractions in Vrindavan. It\'s having a Veg. Indian restaurant in economy rates with delicious food taste & high quality. Hotel is having AC Deluxe room (Double Bed) and Executive Family AC Room (Triple bed). Power Backup on AC, Lift, Room Service, Front Desk, Travel Assistance, CCTV & Security and free parking space are some of other facilities. Main attraction of the city Banke Bihari Ji Temple is just 5 minute walking distance and Iskcon & Prem Mandir are 1 km away. This small budget hotel is newly opened and famous in the area for its best hospitality services. The market and ATM are nearby. Located on main approach road.\r\n       ', 'Hotel Shree Anand Dham img1.png', 'Hotel Shree Anand Dham img2.png', 'Hotel Shree Anand Dham img3.png'),
(6, 'MVT Guesthouse Hotel', 'Bhaktivedanta Swami Marg, Behind ISKCON temple Raman Reti, Uttar Pradesh, 281121 Vrindāvan, India', '24X7', '099977 38666', '-', 'Boasting a garden, terrace, restaurant and free WiFi, MVT Guesthouse & Restaurant is set in Vrindāvan, 47 km from Bharatpur Railway Station and 12 km from Mathura Railway Station. The accommodation offers room service, a 24-hour front desk and currency exchange for guests.\r\nAt the hotel, all rooms are fitted with a wardrobe. Rooms come complete with a private bathroom fitted with a shower and free toiletries, while some units at MVT Guesthouse & Restaurant also have a seating area. All guest rooms at the accommodation feature air conditioning and a desk.\r\n\r\nWildlife SOS is 48 km from MVT Guesthouse & Restaurant, while Lohagarh Fort is 48 km from the property. The nearest airport is Agra Airport, 65 km from the hotel.\r\n        ', 'MVT Guesthouse Hotel img1.jpg', 'MVT Guesthouse Hotel img2.jpg', 'MVT Guesthouse Hotel img3.jpg'),
(1, 'Nidhivan Sarovar Portico Hotel', 'Khasra No. 797, Gopalgarh Tehra Road, Vrindavan, Mathura, Uttar Pradesh - 281121\r\n', '24X7', '074550 27001', '-', 'Nidhivan Sarovar Portico, Vrindavan is a modern contemporary hotel, yet through its thoughtfully designed interiors, captures the essence of the sacred city. Located in the heart of the Mathura district, the hotel is close to the revered Banke Bihari Ji and the magnificent ISCKON Temples.\r\n\r\nThe elegantly furnished hotel rooms with modern-day amenities & pleasing decor exude an ambience of warmth and cosiness to ensure a happy stay. The in-house restaurant - Tripti - serves Pan-Indian delicacies and has one of the best vegetarian cuisines in Vrindavan. The hotel also features an in-house spa offering therapeutic massages. The two banquet halls with state-of-the-art audio-visual equipment, Wi-Fi and customised menus provide the perfect venue for banqueting & conferencing. The hotel also has facilities for specially challenged guests.  <br>\r\n               ', 'Nidhivan_Back_Facade_img.AVIF', 'Nidhivan_Sarovar_Portico_img3.AVIF', 'Nidhivan_King_Bed_mtapzm_img2.AVIF'),
(4, 'Radha Krishna Bhawan Hotel', '21/16 Radha Krishna Bhawan, Bihari Pura, 281121 Vrindāvan, India', '24X7', '-', '-', 'Radha Krishna Bhawan, Homestay offers air-conditioned accommodations in Vrindāvan. This recently renovated homestay is located 46.7 km from Bharatpur Train Station and 12.7 km from Mathura Train Station. The accommodation provides room service and private check-in and check-out for guests.\r\nFree Wifi is accessible to all guests, while selected rooms also offer a terrace. The rooms are equipped with heating facilities.\r\n\r\nGuests at the homestay can enjoy a vegetarian breakfast.', 'Radha Krishna img1.png', 'Radha Krishna img2.png', 'Radha Krishna Bhawan img 3.jpg'),
(5, 'Shree Krishna Bhakti Ashram', 'Goda Vihar, Vrindavan, Uttar Pradesh 281121', '24X7', '098979 19717', '-', 'Shree Krishna Bhakti Ashram is a reasonable option for travellers looking out for villa in Vrindavan. It is located in Rajpur Khadar. Some of the popular transit points from the villa are New Bus Stand (10.9 kms) and Old Bus Stand (11.2 kms). The Villa is in proximity to some popular tourist attractions and other places of interest in Vrindavan. Some of the tourist attractions include Ashta Sakhi Temple (940 mtrs), Vrindavan-Chandra Mandir (1.2 kms), Banke Bihari Temple (1.5 kms), Prem Mandir (1.6 kms), Radhavallabh Temple (1.7 kms), Imlitala Mandir (1.8 kms) and Sri Radha Raman Mandir (2.3 kms).\r\n\r\nFrom all the Budget hotels in Vrindavan, Shree Krishna Bhakti Ashram is very much popular among the tourists. A smooth check-in/check-out process, flexible policies and friendly management garner great customer satisfaction for this property. The Villa has standard Check-In time as 01:00 PM and Check-Out time as 11:00 AM.\r\n\r\nYou can find numerous hotels in Vrindavan under different categories and Shree Krishna Bhakti Ashram is one the best hotel under its category.\r\n             ', 'Radha Krishna img1.png', 'Radha Krishna img2.png', 'Radha Krishna Bhawan img 3.jpg'),
(2, 'Shri Radha Nikunj Hotel', 'Hotel Shri Radha Nikunj Opp. Prem Mandir ,Behind (Chat Chowpaty)', ' 24X7', '+91- 9927200084', '-', 'Hotel Shri Radha Nikunj, located at the prime location as just opposite to Prem Mandir, behind Chat Chowpati in Vrindavan. It offers 85 rooms keys with luxurious stay in three rooms categories i.e. Deluxe King Studio, Executive Suite and Family Suites Rooms. A lush green garden, elevators, a fine dining restaurant, 24hrs. Front Desk, Free Wi-Fi, Free Parking are some other features which make the hotel best choice to stay in Vrindavan. Rooms are spacious equipped with Double bed 6\" spring mattress, sofa cum bed, LED TV, Split ACs, unequipped kitchen, cloth and luggage almirah, separate open balcony and a good interior work in the room.\r\n\r\nRedefining luxury in hospitality, Hotel Shri Radha Nikunj , your all season destination, providing best comforts at the cost of a deluxe budget hotel. Hotel Sangat Regency is located at the center of Vrindavan which is most popular area. Hotel Shri Radha Nikunj established in 2018 at Vrindavan since that point of time Hotel Shri Radha Nikunj is mostly desirable Hotel in vrindavan, mathura.\r\n\r\nThe grand style of our artistically designed building combines modern aspects with traditional touches. The refined interior features the latest trends, luxurious fixtures and a homely atmosphere. The comfortable and contemporary accommodation is individually and warmly decorated with luxurious furnishings it includes an array of incredible modern facilities Come and stay with us to discover a truly unique experience of a Luxury hotel accommodation in Vrindavan Mathura.\r\n\r\n    ', 'Hotel Shri Radha Nikunj img2.jpg', 'Hotel Shri Radha Nikunj img1.jpg', 'Hotel Shri Radha Nikunj img3.jpg'),
(8, 'Shridham Holiday Vrindavan ', 'Krishna crest omaxe Eternity Vrindavan, 281121 Vrindāvan, India ', ' 24x7', '-', '-', ' A sustainable apartment in Vrindāvan, Shridham Holiday Vrindavan offers outdoor fireplace, parking on-site and sports facilities. Among the facilities of this property are a restaurant, a 24-hour front desk and a lift, along with free WiFi. Guests can make use of the children\'s playground or the picnic area, or enjoy views of the mountain and garden.\r\nThe apartment complex will provide guests with air-conditioned units offering a desk, a kettle, a fridge, a safety deposit box, a flat-screen TV, a terrace and a private bathroom with a bath. A fireplace is offered in all units. At the apartment complex, units have bed linen and towels.\r\n\r\nAvailable each morning, the breakfast at the property includes vegetarian dishes along with a selection of fresh pastries and cheese. You can cook your own meal in the kitchen before eating on the private balcony and the apartment also has a coffee shop.\r\n       ', 'Shridham Holiday Vrindavan img1.jpg', 'Shridham Holiday Vrindavan img2.jpg', 'Shridham Holiday Vrindavan img3.jpg'),
(11, 'The Vrindwoods Hotel', 'Rukmani Vihar, behind Sanskar City, Vrindavan, Uttar Pradesh 281121', '24X7', '093192 66666', '-', 'Designed for both business and leisure travel, The Vrindwoods is ideally situated in Vrindavan. The hotel lies 1 km from the city center and provides accessibility to important town facilities. For sightseeing options and local attractions, one need not look far as the hotel enjoys close proximity to Shri Banke Bihari Temple, Iskcon Temple & Others.\r\n', 'the-vrindwoods-hotel img1.jpg', 'the-vrindwoods img2.jpg', 'the-vrindwoods img3.jpg'),
(9, 'Ammaji Restaurant', 'Parikrama Marg, Near Atalla Chungi Shree Bindu Sewa Sansthan, Vrindavan 281121 India', '7:30AM-11:00PM', '99977 10000', '-', ' PRICE RANGE:\r\n           ₹100 - ₹1,000\r\n             CUISINES:\r\n           Indian, Asian\r\n            Special Diets:\r\n            Vegetarian Friendly, Vegan Options, Gluten Free Options', 'ammaji3.jpeg', 'ammaji1.jpg', 'ammaji2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `restuarant`
--

CREATE TABLE `restuarant` (
  `R_ID` int(11) NOT NULL,
  `r_image` text NOT NULL,
  `r_name` text NOT NULL,
  `r_detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `restuarant`
--

INSERT INTO `restuarant` (`R_ID`, `r_image`, `r_name`, `r_detail`) VALUES
(1, 'lostcafe.jpeg', 'Loft Cafe and Restuarants', 'Enjoy the great meaal today, our excellent restaurant is serving up deliciou meals for the whole family.'),
(2, 'food_art_fine.jpeg', 'Food Art', 'Good pizza is the tastiest dish. The great location of this restaurant nakes it easyto reach by anyy transportt terrific service wiill make you feel nice.'),
(3, 'ammaji hotel.jpg', 'Ammaji Restaurant', 'You will be provided Vegetarian cuisine at this restaurant. Order tasty masala dosa, pizza and pasta. Good fruit ice cream deserves ordering. Here you may order delicious cordial. Some guests recommend great lassi, coffee or tea at Ammaji\'s Restaurant.'),
(4, 'agrawal.jpeg', 'Agrawal Restaurant & Banquet', 'Good,tasty food & very neatly restaurant with reasonable price. Good service,good stuff,good cleaning and food quality is also great.'),
(5, 'rathnam.jpeg', 'Shree Rathnam Restaurant', 'It is one of the best fine Restaurant in vrindavan.Specially who love to eat &taste different arts in food.'),
(6, 'centrum.jpeg', 'Centrum Hotel By Brijwasi', 'The hotel provides special guidelines for Poojas and Darshans to guests.\r\nThe hotel located close to numerous famous temples and Gayatri Mandir is just 250 m away from the hotel.\r\nThe hotel does not allow smoking within its premises.'),
(7, 'bigbills.jpg', 'BigBills Restuarants', 'Multi cousine family restaurant, banquet hall, customized gifting products, cakes and biscuits.'),
(8, 'bansal.jpeg', 'Bansal Foods', 'Bansal foods Mathura is the best Vegeterian Awarded Restaurant in mathura which serves Indian & chinese cuisine and speciality in Indian foods. A professional team members who all specialize in their fields provides amazing experience for their guests.'),
(9, 'route.jpg', 'Route66 Cafe & Restro', 'Cafe & restro route 66 restaurant is an enhancng venue nestled in the lush building of the Mystic Palms, Mathura Dine under the luurious ambiance.'),
(10, 'food_garage.jpeg', 'The Food Garage - TFG', 'The Food Garage Resstaurant- Most Delicious multi cousine restaurant of mathura vrndavan.'),
(11, 'ballentine.jpeg', 'Ballentine\'s Restro & Lounge', 'This Spot gives extraordinay service ,yummy meals, Excellent food ,ambience and the staff is very cordial and guests friendly.'),
(12, 'divinity.jpeg', 'Dosa Plaza Divinity', 'Divinity by Audra Hotels, Deeg Gate - Masani Road Opposite Roopam Starworld Cinema, Mathura 281001 India');

-- --------------------------------------------------------

--
-- Table structure for table `restuarant_details`
--

CREATE TABLE `restuarant_details` (
  `re_id` int(11) NOT NULL,
  `re_name` text NOT NULL,
  `re_address` text NOT NULL,
  `re_phone` text NOT NULL,
  `re_details` text NOT NULL,
  `re_img1` text NOT NULL,
  `re_img2` text NOT NULL,
  `re_img3` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `restuarant_details`
--

INSERT INTO `restuarant_details` (`re_id`, `re_name`, `re_address`, `re_phone`, `re_details`, `re_img1`, `re_img2`, `re_img3`) VALUES
(1, 'Loft Cafe and Restuarants', 'Nh-2 Hotel Spiti, Near Mandi Samiti Crossing, Mathura 281004 India', '+91 78381 56660', 'Details:-\r\n            PRICE RANGE:\r\n          ₹300 - ₹700\r\n             CUISINES:\r\n            Mexican, Chinese, Indian, European,\r\n            MEALS:\r\n            Breakfast, Lunch, Dinner', 'loft1.jpeg', 'loft2.jpeg', 'loft3.jpeg'),
(2, 'Food Art', 'Anandam Clarks Inn & Suites Omaxe Eternity, Chhatikara road,vrindavan,up 281121, Vrindavan 281121 India', '+91 95804 70669', 'PRICE RANGE:\r\n            ₹350 - ₹1,000\r\n             CUISINES:\r\n            Chinese, Indian, Thai\r\n            MEALS:\r\n            Breakfast, Lunch, Dinner', 'food1.jpg', 'food2.jpg', 'food3.jpg'),
(3, 'Ammaji Restaurant', 'Parikrama Marg, Near Atalla Chungi Shree Bindu Sewa Sansthan, Vrindavan 281121 India', '99977 10000', 'Details:-\r\n            PRICE RANGE:\r\n           ₹100 - ₹1,000\r\n             CUISINES:\r\n           Indian, Asian\r\n            Special Diets:\r\n           Vegetarian Friendly, Vegan Options, Gluten Free Options', 'ammaji3.jpeg', 'ammaji2.jpg', 'ammaji1.jpg'),
(4, 'Agrawal Restaurant & Banquet', 'Nh-2 Bypass Road, Masani, Mathura - 281003 (Near Maheshwari Hospital)', '+91 7947345337', 'Details:-\r\n            TIMINGS:\r\n           Mon - Sun\r\n                9:00 am - 11:30 pm\r\n             CUISINES:\r\n            Pure Vegetarian, Chinese, Punjabi, South Indian, Multicuisine,\r\n                 North Indian, Jain, Indian, Tandoori, Breakfast, Modern Indian, Fast Food\r\n            TYPE:\r\n            Fine Dining, Food Court, Dhaba, Tiffin Service, Caterers, Delivery Service', 'ag1.jpeg', 'ag2.jpeg', 'ag3.jpeg'),
(5, 'Shree Rathnam Restaurant', 'Main Bazar, Ramanreti Road, Vrindavan Ho, Vrindavan - 281121 (Near Vidhya Peeth Chowk)', '-', 'CUISINES:\r\n            Pure Vegetarian, Punjabi, South Indian, North Indian, Indian\r\n            MEALS:\r\n            Breakfast, Lunch, Dinner', 'rath1.jpeg', 'rath2.jpeg', 'rath3.jpeg'),
(6, 'Centrum Hotel By Brijwasi', 'FMRF+FCQ, and, Bhuteshwar Rd, near New Bus Stand, near New Railway Station, Adarsh Nagar, Manoharpura, Mathura, Uttar Pradesh 281001', '+91 72510 17999', ' Free WiFi\r\n                Free parking\r\n                Family rooms\r\n                Airport shuttle\r\n                Facilities for disabled guests\r\n                \r\n           \r\n             CUISINES:\r\n            Mexican, Chinese, Indian, European\r\n            MEALS:\r\n            Breakfast, Lunch, Dinner', 'centrum1.jpg', 'centrum2.jpeg', 'centrum3.jpeg'),
(7, 'BigBills Restuarants', 'Shankar Rd, Mathura, Uttar Pradesh, India', '+91 80069 99477', 'Features:-\r\n                Сredit cards accepted, Delivery, Outdoor seating, Takeaway, Booking\r\n               CUISINES:\r\n            Mexican, Chinese, Indian, European\r\n            MEALS:\r\n            Breakfast, Lunch, Dinner', 'big2.jpeg', 'big1.jpeg', 'big3.jpeg'),
(8, 'Bansal Foods', 'Bhuteshwar Road Mant Wala Bagicha Near Levis Krishna Nagar, Mathura 281004 India', '+91 70558 44555', 'RICE RANGE:-\r\n                ₹200 - ₹500\r\n               CUISINES:\r\n           \r\n                Indian, Fast food, Chinese, Asian\r\n               \r\n            SPECIAL DIETS\r\n                \r\n            Vegetarian Friendly, Vegan Options', 'BANSAL1.jpg', 'bansal2.jpeg', 'bansal3.jpeg'),
(9, 'Route66 Cafe & Restro', ' outside Transport nagar, NH2, near Mandi Samiti, Shrinathpuram Colony, Naraich, Mathura, Uttar Pradesh 281001', '+91 91055 05111', 'PRICE RANGE:-\r\n                ₹100 - ₹1,000\r\n                CUISINES:\r\n            \r\n            Italian, Indian', 'route1.jpg', 'route2.jpg', 'route3.jpg'),
(10, 'The Food Garage - TFG', 'H7, Masani Rd, near Kalyanam Karoti, Govind Nagar, Mathura, Uttar Pradesh 281003', '+91 90044 02640', 'CUISINES:\r\n            Cafe', 'cafe1.jpg', 'cafe2.jpg', 'cafe1.jpeg'),
(11, 'Ballentine\'s Restro & Lounge', 'near Moti Manzil, Phase 2, Radhika Vihar, Mathura, Uttar Pradesh 281001', '9719722000', 'Cuisines\r\nMulticuisine, North Indian, Indian                \r\nMode of Payment\r\nCash, Cash on Delivery, Card on Delivery, Cheques, Credit Card, Debit Cards, G Pay, JD Pay, NEFT, Paytm, PhonePe, RTGS, RuPay Card, UPI, Visa Car', 'ballentine1.jpeg', 'ballentine2.jpeg', 'ballentine3.jpeg'),
(12, 'Dosa Plaza Divinity', 'Divinity by Audra Hotels, Deeg Gate - Masani Road Opposite Roopam Starworld Cinema, Mathura 281001 India', '+91 89543 00008', 'CUISINES:\r\n            Indian, Chinese, Cafe, Diner, Healthy\r\n            SPECIAL DIETS:-\r\n           \r\n                Vegetarian Friendly, Vegan Options\r\n            MEALS:\r\n            Breakfast, Lunch, Dinner,Drinks', 'divnity1.jpg', 'divnity2.jpg', 'divnity3.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `destination`
--
ALTER TABLE `destination`
  ADD PRIMARY KEY (`D_ID`);

--
-- Indexes for table `destination_details`
--
ALTER TABLE `destination_details`
  ADD KEY `fk_dest` (`dest_id`);

--
-- Indexes for table `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`H_ID`);

--
-- Indexes for table `hotels_details`
--
ALTER TABLE `hotels_details`
  ADD KEY `fk_hotel` (`ho_id`);

--
-- Indexes for table `restuarant`
--
ALTER TABLE `restuarant`
  ADD PRIMARY KEY (`R_ID`);

--
-- Indexes for table `restuarant_details`
--
ALTER TABLE `restuarant_details`
  ADD KEY `fk_restuarant` (`re_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `destination`
--
ALTER TABLE `destination`
  MODIFY `D_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `hotels`
--
ALTER TABLE `hotels`
  MODIFY `H_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `restuarant`
--
ALTER TABLE `restuarant`
  MODIFY `R_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `destination_details`
--
ALTER TABLE `destination_details`
  ADD CONSTRAINT `fk_dest` FOREIGN KEY (`dest_id`) REFERENCES `destination` (`D_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hotels_details`
--
ALTER TABLE `hotels_details`
  ADD CONSTRAINT `fk_hotel` FOREIGN KEY (`ho_id`) REFERENCES `hotels` (`H_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `restuarant_details`
--
ALTER TABLE `restuarant_details`
  ADD CONSTRAINT `fk_restuarant` FOREIGN KEY (`re_id`) REFERENCES `restuarant` (`R_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
